<template>
    <img :src="`${route('root')}/imgs/waves.png`" alt="Logo">
</template>
