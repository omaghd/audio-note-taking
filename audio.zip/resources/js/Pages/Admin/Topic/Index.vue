<template>
    <Head title="Topics" />

    <BreezeAuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Topics
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <div class="flex justify-end mb-6">
                            <input v-model="search" class="border px-2 rounded-lg" placeholder="Search..."
                                   type="text" />
                        </div>

                        <div class="uppercase space-x-2 select-none text-sm text-gray-400 mb-6">
                            <Link
                                :class="{'font-bold text-gray-800' : currentUrl === '/topics' || currentUrl.startsWith(`/topics?search`)}"
                                :href="this.route('topics')"
                                class="hover:text-gray-900"
                                preserveScroll
                                title="GO TO">
                                All topics
                            </Link>
                            <span>|</span>
                            <Link
                                :class="{'font-bold text-gray-800' : currentUrl.startsWith('/topics?done=1')}"
                                :href="this.route('topics', { done: 1 })"
                                class="hover:text-gray-900"
                                preserveScroll
                                title="GO TO">
                                Done topics
                            </Link>
                            <span>|</span>
                            <Link
                                :class="{'font-bold text-gray-800' : currentUrl.startsWith('/topics?undone=1')}"
                                :href="this.route('topics', { undone: 1 })"
                                class="hover:text-gray-900"
                                preserveScroll
                                title="GO TO">
                                Undone topics
                            </Link>
                            <span v-if="$page.props.auth.user.is_admin">|</span>
                            <Link
                                v-if="$page.props.auth.user.is_admin"
                                :class="{'font-bold text-gray-800' : currentUrl.startsWith('/topics?trash=1')}"
                                :href="this.route('topics', { trash: 1 })"
                                class="hover:text-gray-900"
                                preserveScroll
                                title="GO TO">
                                Trash
                            </Link>
                        </div>

                        <div class="flex flex-col">
                            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                                <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                    <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                        <table class="table-auto min-w-full divide-y divide-gray-200">
                                            <thead class="bg-gray-50">
                                                <tr>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Title
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Time
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Audio
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        User
                                                    </th>
                                                    <th class="relative px-6 py-3" scope="col">
                                                        <span class="sr-only">Options</span>
                                                    </th>
                                                </tr>
                                            </thead>

                                            <tbody class="bg-white divide-y divide-gray-200">
                                                <tr v-for="topic in topics.data" :key="topic.id">
                                                    <td :class="{'border-l-4 border-green-400': topic.is_done}"
                                                        class="px-6 py-4 whitespace-nowrap">
                                                        <div class="flex items-center">
                                                            <div class="font-medium text-gray-900">
                                                                {{ topic.title }}
                                                                <p v-if="topic.done_at" class="text-xs text-gray-400">
                                                                    DONE AT: {{ topic.done_at }}
                                                                </p>
                                                                <p v-else class="text-xs text-gray-400">
                                                                    <font-awesome-icon icon="minus" />
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="flex items-center">
                                                            <div class="text-sm font-medium text-gray-900">
                                                                {{ formatSeconds(topic.time) }}
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="flex items-center">
                                                            <div class="text-sm font-medium text-gray-900">
                                                                <Link
                                                                    :href="this.route('audios.topics', topic.audio.id)"
                                                                    class="text-sky-600 hover:text-sky-900 mr-6"
                                                                    title="GO TO">
                                                                    {{ topic.audio.title }}
                                                                </Link>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="flex items-center">
                                                            <div class="text-sm font-medium text-gray-900">
                                                                <Link :href="this.route('users.topics', topic.user.id)"
                                                                      class="text-sky-600 hover:text-sky-900"
                                                                      title="See all topics">
                                                                    {{ topic.user.name }}
                                                                </Link>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                        <div
                                                            v-if="topic.user_id === $page.props.auth.user.id || $page.props.auth.user.is_admin">
                                                            <Link
                                                                v-if="topic.deleted_at"
                                                                :href="this.route('topics.restore', topic.id)"
                                                                class="px-4 py-2 rounded text-green-900 bg-green-200 hover:bg-green-300"
                                                                title="Restore"
                                                                method="patch"
                                                                preserveScroll>
                                                                <font-awesome-icon icon="arrow-rotate-left" />
                                                            </Link>
                                                            <Link
                                                                v-else
                                                                :href="this.route('topics.destroy', topic.id)"
                                                                class="px-4 py-2 rounded text-red-900 bg-red-200 hover:bg-red-300"
                                                                title="Delete"
                                                                method="delete"
                                                                preserveScroll>
                                                                <font-awesome-icon icon="trash" />
                                                            </Link>
                                                        </div>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <Pagination :links="topics.links" class="mt-6"></Pagination>
                    </div>
                </div>
            </div>
        </div>
    </BreezeAuthenticatedLayout>
</template>

<script setup>
import Pagination from '@/Shared/Pagination';
import { computed, ref, watch } from "vue";
import { Inertia } from "@inertiajs/inertia";
import debounce from "lodash/debounce";
import { usePage } from "@inertiajs/inertia-vue3";

let props = defineProps({
    topics: Object,
    filters: Object
})

let search = ref(props.filters.search);

watch(search, debounce(function (value) {
    Inertia.get(route('topics', query.value), { search: value }, { preserveState: true, replace: true });
}, 300));

let formatSeconds = (seconds) => {
    if (isNaN(seconds)) seconds = 0;
    return new Date(seconds * 1000).toISOString().substr(11, 8);
}

const currentUrl = computed(() => usePage().url.value);

const query = computed(() => {
    if (currentUrl.value.startsWith('/topics?done'))
        return { done: 1 };
    else if (currentUrl.value.startsWith('/topics?undone'))
        return { undone: 1 };
    else if (currentUrl.value.startsWith('/topics?trash'))
        return { trash: 1 };
    return {};
});
</script>

